package excercicio2;

public abstract class AcervoBibliográfico {

	String identifAcervo;
	int paginas;
	String autor;
	int anopub;
	String edit;
	
}
