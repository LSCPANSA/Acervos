package excercicio2;

public class Lvr3 extends AcervoBibliográfico{

}
