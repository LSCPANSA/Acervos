package excercicio2;

public class Lvr1 extends AcervoBibliográfico {

	
	
}
