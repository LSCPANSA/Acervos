package excercicio2;

public class Lvr2 extends AcervoBibliográfico{

}
